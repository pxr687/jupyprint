""" Jupyprint package
"""
__version__ = "0.1.6"

from .jupyprint import jupyprint, to_md, arraytex
