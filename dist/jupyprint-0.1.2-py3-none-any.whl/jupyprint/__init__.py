""" Jupyprint package
"""
__version__ = "0.1.2"

from .jupyprint import jupyprint, to_md, arraytex
