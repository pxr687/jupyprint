""" Jupyprint package
"""
__version__ = "0.1.3"

from .jupyprint import jupyprint, to_md, arraytex
